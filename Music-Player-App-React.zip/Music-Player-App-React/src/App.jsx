import { useState, useRef, useEffect } from "react";
import { FaPlay, FaPause, FaStop, FaHeart, FaStepForward, FaStepBackward, FaVolumeUp } from "react-icons/fa";
import "./App.css";

const App = () => {
  const songs = [
    { title: "Night Drive", artist: "Silent Partner", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3" },
    { title: "Vibes", artist: "Kevin MacLeod", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3" },
    { title: "Serenity", artist: "Bensound", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3" },
    { title: "Dreams", artist: "Bensound", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3" },
    { title: "Space Walk", artist: "Silent Partner", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3" },
    { title: "Sunrise", artist: "Jingle Punks", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3" },
    { title: "Waves", artist: "Kevin MacLeod", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3" },
    { title: "Chances", artist: "Silent Partner", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" },
    { title: "Don't Hate Me", artist: "Jingle Punks", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3" },
    { title: "Ocean", artist: "Bensound", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3" },
    { title: "Cloud Nine", artist: "Kevin MacLeod", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-11.mp3" },
    { title: "Eclipse", artist: "Jingle Punks", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3" },
    { title: "Calm", artist: "Bensound", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-13.mp3" },
    { title: "Horizon", artist: "Silent Partner", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-14.mp3" },
    { title: "Echo", artist: "Kevin MacLeod", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-15.mp3" },
    { title: "Lush Forest", artist: "Bensound", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-20.mp3" },
    { title: "Midnight", artist: "Bensound", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-16.mp3" },]

  const [currentSongIndex, setCurrentSongIndex] = useState(-1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [likedSongs, setLikedSongs] = useState([]);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [showLikedSongs, setShowLikedSongs] = useState(false);
  const audioRef = useRef(new Audio());

  useEffect(() => {
    const audio = audioRef.current;
    const updateTime = () => setCurrentTime(audio.currentTime);
    const updateDuration = () => setDuration(audio.duration);
    audio.addEventListener("timeupdate", updateTime);
    audio.addEventListener("loadedmetadata", updateDuration);
    audio.addEventListener("ended", playNext);
    return () => {
      audio.removeEventListener("timeupdate", updateTime);
      audio.removeEventListener("loadedmetadata", updateDuration);
      audio.removeEventListener("ended", playNext);
    };
  }, [currentSongIndex]);

  const playSong = (index) => {
    const song = songs[index];
    if (audioRef.current) {
      audioRef.current.src = song.url;
      audioRef.current.play();
      setCurrentSongIndex(index);
      setIsPlaying(true);
    }
  };

  const togglePlayPause = () => {
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const stopSong = () => {
    audioRef.current.pause();
    audioRef.current.currentTime = 0;
    setIsPlaying(false);
    setCurrentSongIndex(-1);
  };

  const playNext = () => {
    const nextIndex = (currentSongIndex + 1) % songs.length;
    playSong(nextIndex);
  };

  const playPrevious = () => {
    const prevIndex = (currentSongIndex - 1 + songs.length) % songs.length;
    playSong(prevIndex);
  };

  const toggleLike = (song, e) => {
    const isLiked = likedSongs.includes(song);
    setLikedSongs((prev) =>
      isLiked ? prev.filter((s) => s !== song) : [...prev, song]
    );
    e.target.style.transform = isLiked ? "scale(1)" : "scale(1.2)";
    setTimeout(() => (e.target.style.transform = "scale(1)"), 200);
  };

  const handleSeek = (e) => {
    const newTime = e.target.value;
    audioRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const handleVolume = (e) => {
    const newVolume = e.target.value;
    audioRef.current.volume = newVolume;
    setVolume(newVolume);
  };

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds < 10 ? "0" + seconds : seconds}`;
  };

  return (
    <div className="container">
      <h1 className="title">Viberation 🎵</h1>
      <div className="main-content">
        <div className="header">
          <button
            className="liked-songs-button"
            onClick={() => setShowLikedSongs(!showLikedSongs)}
          >
            Liked Songs ({likedSongs.length})
          </button>
        </div>
        {showLikedSongs && likedSongs.length > 0 && (
          <div className="liked-songs-section">
            <h2 className="section-title">Liked Songs</h2>
            <div className="song-grid">
              {likedSongs.map((song, index) => (
                <div key={index} className="song-card">
                  <h2 className="song-title">{song.title}</h2>
                  <p className="song-artist">{song.artist}</p>
                  <div className="controls">
                    <button
                      className="play-button"
                      onClick={() => playSong(songs.indexOf(song))}
                    >
                      <FaPlay />
                    </button>
                    <button className="stop-button" onClick={stopSong}>
                      <FaStop />
                    </button>
                    <button
                      className="like-button"
                      style={{ color: "#ff4d4d" }}
                      onClick={(e) => toggleLike(song, e)}
                    >
                      <FaHeart />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        <div className="song-grid">
          {songs.map((song, index) => (
            <div
              key={index}
              className="song-card"
              style={{
                backgroundColor: currentSongIndex === index && isPlaying ? "#a0a0a0" : "#e0e0e0",
              }}
            >
              <h2 className="song-title">{song.title}</h2>
              <p className="song-artist">{song.artist}</p>
              <div className="controls">
                <button
                  className="play-button"
                  onClick={() => (currentSongIndex === index && isPlaying ? togglePlayPause() : playSong(index))}
                >
                  {currentSongIndex === index && isPlaying ? <FaPause /> : <FaPlay />}
                </button>
                <button className="stop-button" onClick={stopSong}>
                  <FaStop />
                </button>
                <button
                  className="like-button"
                  style={{ color: likedSongs.includes(song) ? "#ff4d4d" : "#666" }}
                  onClick={(e) => toggleLike(song, e)}
                >
                  <FaHeart />
                </button>
              </div>
            </div>
          ))}
        </div>
        {currentSongIndex >= 0 && (
          <div className="player">
            <div className="now-playing">
              <h2 className="now-playing-text">
                {songs[currentSongIndex].title} - {songs[currentSongIndex].artist}
              </h2>
            </div>
            <div className="player-controls">
              <button className="control-button" onClick={playPrevious}>
                <FaStepBackward />
              </button>
              <button className="control-button" onClick={togglePlayPause}>
                {isPlaying ? <FaPause /> : <FaPlay />}
              </button>
              <button className="control-button" onClick={playNext}>
                <FaStepForward />
              </button>
            </div>
            <div className="progress-container">
              <span className="time">{formatTime(currentTime)}</span>
              <input
                type="range"
                min="0"
                max={duration || 100}
                value={currentTime}
                onChange={handleSeek}
                className="progress-bar"
              />
              <span className="time">{formatTime(duration)}</span>
            </div>
            <div className="volume-container">
              <FaVolumeUp className="volume-icon" />
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={volume}
                onChange={handleVolume}
                className="volume-bar"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default App;